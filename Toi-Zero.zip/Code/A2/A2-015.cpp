//Author : PasitHexaHydride
#include <bits/stdc++.h>
using namespace std; 

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int w, l, n, p;
    cin >> w >> l >> n >> p;
    cout << 2LL * (w + l) * n << "\n" << 2LL * (w + l) * n * p;
}