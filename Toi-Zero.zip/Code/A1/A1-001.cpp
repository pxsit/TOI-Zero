//Author : PasitHexaHydride
#include <bits/stdc++.h>
using namespace std;

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    string a,b;
    cin >> a >> b;
    cout << "Hello" << ' ' << a << ' ' << b << '\n' << a[0] <<a[1] <<b[0] << b[1];
}