//Author : PasitHexaHydride
#include <bits/stdc++.h>
using namespace std;

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    char a;
    cin >> a;
    if(a == 'a' || a == 'e' || a == 'i' || a == 'o' || a == 'u') cout << "yes";
    else cout << "no";
}