//Author : PasitHexaHydride
#include <bits/stdc++.h>
using namespace std;

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    string a;
    cin >> a;
    if(a[2] == '1' && a[3] == '6') cout << "yes";
    else cout << "no";
}