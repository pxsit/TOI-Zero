//Author : PasitHexaHydride
#include <bits/stdc++.h>
using namespace std;

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    string s;
cin >> s;;
    if(s.length() == 13) cout << "yes";
    else cout << "no";
}